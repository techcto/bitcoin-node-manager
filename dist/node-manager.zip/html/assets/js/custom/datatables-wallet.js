$(document).ready(function () {
  $("#txmempool").DataTable({
    paging: false,
    bInfo: false,
    order: [],
    bFilter: false,
  });
});
